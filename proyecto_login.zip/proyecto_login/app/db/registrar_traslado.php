<?php
session_start();
if (!isset($_SESSION["s_username"])) {
    header("Location: ../login/index.php");
    exit();
}

include '../db/conexion.php';
$objeto = new Conexion();
$conexion = $objeto->Conectar();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validar que todos los datos requeridos estén presentes
    if (
        !isset($_POST['planta_id']) || 
        !isset($_POST['cantidad_tr']) || 
        !isset($_POST['fecha_traslado']) || 
        !isset($_POST['observ']) 
    ) {
        echo json_encode(["status" => "error", "message" => "Faltan datos obligatorios."]);
        exit();
    }

    $planta_id = $_POST['planta_id'];
    $cantidad_tr = intval($_POST['cantidad_tr']);
    $fecha_traslado = $_POST['fecha_traslado'];
    $observ = $_POST['observ'];

    try {
        // Verificar la cantidad disponible de la planta
        $query = "SELECT cantidad FROM plantas WHERE id = ? AND id = 'traslado'";
        $stmt = $conexion->prepare($query);
        $stmt->execute([$planta_id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($resultado) {
            $cantidad_disponible = intval($resultado['cantidad']);

            // Verificar si la cantidad a trasplantar excede la cantidad disponible
            if ($cantidad_tr > $cantidad_disponible) {
                echo json_encode(["status" => "error", "message" => "Cantidad a trasladar excede la cantidad disponible."]);
                exit();
            }

            // Actualizar la cantidad disponible de plantas a 0
            $update_query = "UPDATE plantas SET cantidad = 0 WHERE id = ?";
            $update_stmt = $conexion->prepare($update_query);
            $update_stmt->execute([$planta_id]);

            // Calcular la diferencia (la cantidad de plantas que no fueron trasplantadas)
            $perdida_t = $cantidad_disponible - $cantidad_tr;

            // Registrar el trasplante con la pérdida de plantas
            $insert_query = "INSERT INTO planta_traslado (plantas_id, fecha_traslado, cantidad_tr, observ, perdida_t) 
                             VALUES (?, ?, ?, ?, ?)";
            $insert_stmt = $conexion->prepare($insert_query);
            $insert_stmt->execute([$planta_id, $fecha_traslado, $cantidad_tr, $observ, $perdida_t]);

            echo json_encode(["status" => "success", "message" => "Traslado registrado exitosamente."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Planta no encontrada o no está en trasplante."]);
        }
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "Error al registrar el traslado: " . $e->getMessage()]);
    }
}
?>
