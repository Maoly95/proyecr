<?php
session_start();

// Si la sesión no está activa, redirigir a la página de login
if (!isset($_SESSION["s_username"])) {
    header("Location: ../login/index.php");
    exit();
}

require_once "vistas/parte_superior.php"; 

// Conexión a la base de datos
include '../db/conexion.php'; 
$objeto = new Conexion();
$conexion = $objeto->Conectar();

try {
    // Consulta SQL
    $query = "SELECT ptr.id, pt.id AS planta, ptr.fecha_traslado, ptr.cantidad_tr AS cantidad, ptr.observ, ptr.per_traslado 
          FROM planta_traslado ptr 
          INNER JOIN planta_trasplante pt ON ptr.id = pt.id";

    $resultado = $conexion->prepare($query);
    $resultado->execute();

    // Verificar resultados
    $data = [];
    if ($resultado->rowCount() > 0) {
        while ($row = $resultado->fetch(PDO::FETCH_ASSOC)) {
            $data[] = $row; // Guardar los resultados en un array
        }
    } else {
        echo "No se encontraron registros.";
    }
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}
?>

<!--INICIO del cont principal-->
<div class="container">
    <h1>Plantas - Traslado</h1>
    
    <div class="row">
        <div class="col-lg-12">
        <button id="btnNuevo" type="button" class="btn btn-success" data-toggle="modal" data-target="#modalCRUD">Registrar Traslado</button>           
        <a href="fpdf/generar_reporte.php" target="_blank" class="btn btn-success"> Descargar Reporte </a>  
        </div>
    </div>
    
    <br>  
    <div class="row">
        <div class="col-lg-12">
            <div class="table-responsive">        
                <table id="tablaPersonas" class="table table-striped table-bordered table-condensed" style="width:100%">
                    <thead class="text-center">
                        <tr>
                            <th>Nº</th>
                            <th>Planta</th>
                            <th>Fecha de Traslado</th>
                            <th>Cantidad</th>
                            <th>Observación</th>
                            <th>Diferencia</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        foreach($data as $dat) {   
                        ?>
                            <tr data-id="<?php echo $dat['id']; ?>">
                                <td><?php echo $dat['id'] ?></td>                            
                                <td><?php echo $dat['planta'] ?></td>
                                <td><?php echo $dat['fecha_traslado'] ?></td>
                                <td><?php echo $dat['cantidad_tr'] ?></td>
                                <td><?php echo $dat['observ'] ?></td>
                                <td><?php echo $dat['per_traslado'] ?></td>
                                <td>
                                    <button class="btnEdit btn btn-info" data-toggle="modal" data-target="#modalCRUD"><i class="fas fa-solid fa-pen"></i></button>
                                    <button class="btnDelete btn btn-danger"><i class="fas fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                        <?php } ?>                                
                    </tbody>        
                </table>                    
            </div>
        </div>
    </div>  
</div>

<!-- Modal para agregar trasplante -->
<div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Registrar Traslado</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form id="formPlanta_traslado">
                <div class="modal-body">
                    <div class="form-group">
                    <label for="plantas_id">Seleccionar Planta:</label>
                    <select name="plantas_id" class="form-control" id="plantas_id" required> 
                    <?php
                            // Obtener plantas en estado de trasplante
                            $query = "SELECT id, plantas_id, cantidad FROM planta_trasplante";
                            $resultado = $conexion->query($query);
                            
                            while ($row = $resultado->fetch(PDO::FETCH_ASSOC)) {
                                echo "<option value='{$row['id']}' data-cantidad='{$row['cantidad']}'>{$row['nombre_comun']}</option>";
                            }
                        
                        ?>
                    </select>
                    </div>
                    <div class="form-group">
                        <label for="cantidad">Cantidad Disponible:</label>
                        <input type="number" class="form-control" id="cantidad" readonly />
                    </div>
                    <div class="form-group">
                        <label for="cantidad_tr">Cantidad a Trasladar:</label>
                        <input type="number" class="form-control" id="cantidad_tr" required />
                    </div>
                    <div class="form-group">
                        <label for="per_traslado">Diferencia:</label>
                        <input type="number" class="form-control" id="per_traslado" readonly />
                    </div>
                    <div class="form-group">
                        <label for="fecha_traslado" class="col-form-label">Fecha de Traslado:</label>
                        <input type="date" class="form-control" id="fecha_traslado" required />
                    </div>
                    <div class="form-group">
                        <label for="observ" class="col-form-label">Observación:</label>
                        <input type="text" class="form-control" id="observ" required />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-success">Registrar Traslado</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function() {
    $('#plantas_id').change(function() {
        const selectedOption = $(this).find('option:selected');
        const cantidad = parseInt(selectedOption.data('cantidad'));
        $('#cantidad').val(cantidad);
        $('#per_traslado').val('');
    });

    $('#cantidad_t').on('input', function() {
        const cantidad = parseInt($('#cantidad').val());
        const cantidad_tr = parseInt($(this).val()) || 0;
        const per_traslado = cantidad - cantidad_tr;
        $('#per_traslado').val(per_traslado);
    });

    $('#formPlanta_traslado').submit(function(e) {
        e.preventDefault();

        const planta_id = $('#plantas_id').val();
        const cantidad_tr = $('#cantidad_tr').val();
        const fecha_traslado = $('#fecha_traslado').val();
        const observacion = $('#observ').val();
        const per_traslado = $('#per_traslado').val();

        $.ajax({
            url: '../db/registar_traslado.php',
            type: 'POST',
            dataType: 'json',
            data: { plantas_id, cantidad_tr, fecha_traslado, observ, per_traslado },
            success: function(data) {
                alert(data.message);
                $('#modalCRUD').modal('hide');
                location.reload();
            },
            error: function(xhr) {
                alert("Error al registrar el traslado.");
                console.error(xhr.responseText);
            }
        });
    });
});
</script>

<?php require_once "vistas/parte_inferior.php"; ?>
