<?php
// Conectar a la base de datos
include_once ('conexion.php'); // Asegúrate de incluir tu archivo de conexión

// Consultar datos
$query = "SELECT * FROM plantas";
$result = $conexion->query($query);
$objeto = new Conexion();
$conexion = $objeto->Conectar();

$consulta_info = $conexion->query(" select *from plantas ");//traemos datos de la empresa desde BD
$dato_info = $consulta_info->fetch_object();
$consulta = "SELECT id, nombre_comun, nombre_cien, fecha_siembra, etapa, tipo, cantidad, fecha_registro FROM plantas";
$resultado = $conexion->prepare($consulta);

if (!$resultado) {
   die("Error en la consulta: " . implode(", ",$conexion -> errorInfo())); 
}

$resultado -> execute();
$data = $resultado -> fetchAll(PDO::FETCH_ASSOC);

// Crear el PDF e incluir los datos obtenidos
$pdf = new PDF($data); 
$pdf -> AddPage(); 
$pdf -> AliasNbPages(); 

// Mostrar los datos en el PDF
$pdf -> mostrarDatos(); 

// Salida del PDF
$pdf -> Output('Prueba.pdf' ,'I'); // nombreDescarga , Visor(I -> visualizar - D -> descargar)

require('./fpdf.php');


class PDF extends FPDF
{
    private $data; // Variable para almacenar los datos

    // Constructor para recibir los datos
    function __construct($data)
    {
        parent::__construct(); // Llamar al constructor padre
        $this->data = $data; // Almacenar los datos
    }

    // Cabecera de página
    function Header()
    {
        $this->Image('logo.png', 185, 5, 20); // Logo de la empresa
        $this->SetFont('Arial', 'B', 19);
        $this->Cell(45);
        $this->SetTextColor(0, 0, 0);
        $this->Cell(110, 15, utf8_decode('FUNDACIÓN JARDIN BOTANICO EZEQUIEL ZAMORA'), 1, 1, 'C', 0);
        $this->Ln(3);
        $this->SetTextColor(103);

        /* UBICACION */
        $this->Cell(110);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(96, 10, utf8_decode("Ubicación : "), 0, 0, '', 0);
        $this->Ln(5);

        /* TELEFONO */
        $this->Cell(110);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(59, 10, utf8_decode("Teléfono : "), 0, 0, '', 0);
        $this->Ln(5);

        /* CORREO */
        $this->Cell(110);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(85, 10, utf8_decode("Correo : "), 0, 0, '', 0);
        $this->Ln(5);

        /* Sucursal */
        $this->Cell(110);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(85, 10, utf8_decode("Sucursal : "), 0, 0, '', 0);
        $this->Ln(10);

        /* TITULO DE LA TABLA */
        $this->SetTextColor(228, 100, 0);
        $this->Cell(50);
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(100, 10, utf8_decode("FUNDACIÓN JARDIN BOTANICO EZEQUIEL ZAMORA"), 0, 1, 'C', 0);
        $this->Ln(7);

        /* CAMPOS DE LA TABLA */
        // Color
        $this->SetFillColor(228, 100, 0); // Color fondo
        $this->SetTextColor(255, 255, 255); // Color texto
        $this->SetDrawColor(163, 163, 163); // Color borde
        $this->SetFont('Arial', 'B',5 );
        
        // Encabezados de la tabla
        $this->Cell(9, 10, utf8_decode('N°'), 1, 0, 'C', 1);
        $this->Cell(20, 10, utf8_decode('NOMBRE'), 1, 0, 'C', 1);
        $this->Cell(30, 10, utf8_decode('NOMBRE CIENTIFICO'), 1, 0, 'C', 1);
        $this->Cell(25, 10, utf8_decode('FECHA DE SIEMBRA'), 1, 0, 'C', 1);
        $this->Cell(25, 10, utf8_decode('ETAPA'), 1, 0, 'C', 1);
        $this->Cell(25, 10, utf8_decode('TIPO'), 1, 0, 'C', 1);
        $this->Cell(25, 10, utf8_decode('CANTIDAD'), 1, 1, 'C', 1);
    }

    // Pie de página
    function Footer()
    {
       // Posición: a un cm del final
       $this->SetY(-15); 
       // Tipo fuente y tamaño
       $this->SetFont('Arial', 'I', 8); 
       // Pie de página (número de página)
       $this->Cell(0,10,'Página '.$this->PageNo().'/{nb}',0 ,0,'C'); 
       // Fecha actual en pie de página
       $hoy = date('d/m/Y');
       $this->Cell(355 ,10 ,utf8_decode($hoy),0 ,0,'C'); 
    }

    // Método para mostrar los datos en el PDF
    function mostrarDatos()
    {
       foreach ($this->data as $row) {
           // Aquí se agregan las filas con los datos desde la consulta
           static $i = -1; 
           if ($i < count($row)) {
               ++$i;
           }
           else {
               return;
           }
           // Ajustar las celdas según tus necesidades
           $this->Cell(9 ,10 ,$i +1 ,1 ,0 ,'C');
           foreach ($row as $field) {
               if ($field === null) {
                   continue; 
               }
               if (is_string($field)) {
                   if (mb_strlen($field) >25) { 
                       // Limitar longitud si es necesario
                       mb_substr($field ,0 ,25).'...'; 
                   }
                   else {
                       utf8_decode($field); 
                   }
               }
               else {
                   utf8_decode($field); 
               }
               // Añadir celdas para cada campo
               //$pdf -> Cell(...); 
           }
           //$pdf -> Ln(); 
       }
   }
}
?>

// Conectar a la base de datos y ejecutar la consulta antes de crear el PDF
