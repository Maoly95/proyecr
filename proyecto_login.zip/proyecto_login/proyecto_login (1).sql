-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-01-2025 a las 06:14:42
-- Versión del servidor: 10.1.36-MariaDB
-- Versión de PHP: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto_login`
--
CREATE DATABASE IF NOT EXISTS `proyecto_login` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `proyecto_login`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abono`
--

CREATE TABLE `abono` (
  `id` int(11) NOT NULL,
  `kil_os` decimal(10,2) NOT NULL,
  `fech_a` date NOT NULL,
  `fech_reg` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `abono`
--

INSERT INTO `abono` (`id`, `kil_os`, `fech_a`, `fech_reg`) VALUES
(1, '500.00', '2024-12-03', '2025-01-07 17:02:34'),
(2, '12.00', '2024-12-09', '2025-01-07 17:02:34'),
(3, '0.00', '0000-00-00', '2025-01-07 17:02:34'),
(4, '0.00', '0000-00-00', '2025-01-07 17:02:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gastos`
--

CREATE TABLE `gastos` (
  `id` int(11) NOT NULL,
  `responsable` varchar(30) NOT NULL,
  `fecha` date NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `razon` varchar(100) NOT NULL,
  `fech_gas` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `gastos`
--

INSERT INTO `gastos` (`id`, `responsable`, `fecha`, `total`, `razon`, `fech_gas`) VALUES
(1, 'maoly balza', '2024-12-09', '120.00', 'papeleria', '2024-12-12 01:22:08'),
(3, 'luis gonzalez', '2024-12-10', '500.00', 'taxi', '2024-12-12 01:22:08'),
(5, 'jesus peraza', '2024-12-10', '2.00', 'gasolina', '2024-12-12 01:22:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `humus`
--

CREATE TABLE `humus` (
  `id` int(11) NOT NULL,
  `tipo_h` set('liquido','solido') NOT NULL COMMENT 'tipo de humus (liquido o solido)',
  `cantidad_h` decimal(10,2) NOT NULL,
  `fecha_rh` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `humus`
--

INSERT INTO `humus` (`id`, `tipo_h`, `cantidad_h`, `fecha_rh`) VALUES
(1, 'solido', '20.00', '2025-01-07 17:04:19'),
(2, 'liquido', '44.00', '2025-01-07 17:04:19'),
(3, 'liquido', '33.00', '2025-01-07 17:04:19'),
(8, 'liquido', '2.00', '2025-01-07 17:04:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plantas`
--

CREATE TABLE `plantas` (
  `id` int(11) NOT NULL,
  `nombre_comun` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `nombre_cien` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `fecha_siembra` date NOT NULL,
  `etapa` text COLLATE utf8mb4_bin NOT NULL,
  `tipo` text COLLATE utf8mb4_bin NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Volcado de datos para la tabla `plantas`
--

INSERT INTO `plantas` (`id`, `nombre_comun`, `nombre_cien`, `fecha_siembra`, `etapa`, `tipo`, `cantidad`, `fecha_registro`) VALUES
(38, 'marihuana', 'limonarius', '2024-12-03', 'pre-germinacion', 'ornamental', 222, '2025-01-09 05:11:21'),
(39, 'prueba', 'pooooooo', '2024-12-03', 'pre-germinacion', 'frutal', 15, '2025-01-09 05:10:59'),
(51, 'prueba', 'poo', '2024-12-03', 'pre-germinacion', 'frutal', 15, '2025-01-09 05:10:48');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planta_transplante`
--

CREATE TABLE `planta_transplante` (
  `id` int(11) NOT NULL,
  `planta_id` int(11) NOT NULL,
  `fecha_transplante` date NOT NULL,
  `tipo_suelo` varchar(50) NOT NULL,
  `cantidad` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planta_traslado`
--

CREATE TABLE `planta_traslado` (
  `id` int(11) NOT NULL,
  `planta_id` int(11) NOT NULL,
  `fecha_traslado` date NOT NULL,
  `ubicacion` varchar(100) NOT NULL,
  `cantidad` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(50) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `descripcion`) VALUES
(1, 'Admin'),
(2, 'Botanico'),
(3, 'Director');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `username` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(70) COLLATE utf8mb4_bin NOT NULL,
  `idRol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `password`, `idRol`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `abono`
--
ALTER TABLE `abono`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `gastos`
--
ALTER TABLE `gastos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `humus`
--
ALTER TABLE `humus`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `plantas`
--
ALTER TABLE `plantas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre_cientifico` (`nombre_cien`);

--
-- Indices de la tabla `planta_transplante`
--
ALTER TABLE `planta_transplante`
  ADD PRIMARY KEY (`id`),
  ADD KEY `planta_id` (`planta_id`);

--
-- Indices de la tabla `planta_traslado`
--
ALTER TABLE `planta_traslado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `planta_id` (`planta_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`username`),
  ADD KEY `IDRol` (`idRol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `abono`
--
ALTER TABLE `abono`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `gastos`
--
ALTER TABLE `gastos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `humus`
--
ALTER TABLE `humus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `plantas`
--
ALTER TABLE `plantas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT de la tabla `planta_transplante`
--
ALTER TABLE `planta_transplante`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `planta_traslado`
--
ALTER TABLE `planta_traslado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `planta_transplante`
--
ALTER TABLE `planta_transplante`
  ADD CONSTRAINT `fk_planta_transplante` FOREIGN KEY (`planta_id`) REFERENCES `plantas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `planta_traslado`
--
ALTER TABLE `planta_traslado`
  ADD CONSTRAINT `fk_planta_traslado` FOREIGN KEY (`planta_id`) REFERENCES `plantas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`idRol`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
